
# *************************************************************************
# ***              NO TOQUE LOS ARCHIVOS DE ESTE DIRECTORIO                ***
# *** LOS ARCHIVOS DE ESTE DIRECTORIO Y SUBDIRECTORIOS CONSTITUYEN UNA BASE DE DATOS DE DERBY,     ***
# *** QUE INCLUYE LOS DATOS (USUARIO Y SISTEMA) Y LOS       ***
# *** ARCHIVOS NECESARIOS PARA UNA RECUPERACIÓN DE LA BASE DE DATOS.                            ***
# *** LA EDICIÓN, ADICIÓN O SUPRESIÓN DE CUALQUIER ARCHIVO PUEDE PROVOCAR    ***
# *** CORRUPCIÓN DE DATOS Y UN ESTADO NO RECUPERABLE EN LA BASE DE DATOS.     ***
# *************************************************************************