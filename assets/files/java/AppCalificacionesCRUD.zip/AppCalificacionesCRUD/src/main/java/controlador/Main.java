package controlador;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import vista.FrameCalificaciones;

/**
 *
 * @author chavez
 */
public class Main {

    public static void main(String[] args) {
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            Connection conexion = DriverManager.getConnection("jdbc:derby:basededatos;create=true");
            DatabaseMetaData metadata = conexion.getMetaData();
            ResultSet resultado = metadata.getTables(null, null, null, new String[]{"TABLE"});
            if (!resultado.next()) {
                String sql = "CREATE TABLE calificacion(clave INT PRIMARY KEY"
                        + " GENERATED ALWAYS AS IDENTITY(Start with 1, Increment by 1),"
                        + " aciertos INTEGER,"
                        + " fecha VARCHAR(10)," // 08-05-2021
                        + " test INTEGER)";
                Statement sentencia = conexion.createStatement();
                sentencia.execute(sql);
                System.out.println("Base de Datos creada");
            } else {
                System.out.println("Ya existe la BD");
            }
            resultado.close();
            conexion.close();
            DriverManager.getConnection("jdbc:derby:basededatos;shutdown=true");
        } catch (ClassNotFoundException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 45000 && ex.getSQLState().equals("08006")) {
                System.out.println("Base de datos cerrada correctamente");
            } else {
                System.err.println(ex);
            }
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameCalificaciones().setVisible(true);
            }
        });
    }

}
