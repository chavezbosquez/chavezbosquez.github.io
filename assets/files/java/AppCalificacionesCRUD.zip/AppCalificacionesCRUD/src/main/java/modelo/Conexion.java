/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author chavez
 */
public class Conexion {

    public Connection getConexion() {
        try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            Connection conexion = DriverManager.getConnection("jdbc:derby:basededatos;create=true");
            return conexion;
        } catch (ClassNotFoundException ex) {
            System.err.println(ex);
            return null;
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 45000 && ex.getSQLState().equals("08006")) {
                System.out.println("Base de datos cerrada correctamente");
            } else {
                System.err.println(ex);
            }
            return null;
        }
    }
    
    public boolean guardarDatos(int aciertos, String fecha, int test) {
        Connection conexion = this.getConexion();
        try {
            PreparedStatement psInsert = conexion.prepareStatement(
                            "INSERT INTO calificacion(aciertos,fecha,test) VALUES(?,?,?)");
            psInsert.setInt(1, aciertos);
            psInsert.setString(2, fecha);
            psInsert.setInt(3, test);
            psInsert.executeUpdate();
            psInsert.close();
            conexion.close();
            return true;
        } catch (SQLException ex) {
            System.err.println(ex);
            return false;
        }
    }

    public void cerrarConexion() {
        try {
            DriverManager.getConnection("jdbc:derby:basededatos;shutdown=true");
        } catch (SQLException ex) {
            if ( ex.getErrorCode() == 45000 && ex.getSQLState().equals("08006") ) {
                System.out.println("Base de datos cerrada correctamente");
            } else {
                System.err.println(ex);
            }
        }
    }

    public String getDatos() {
        Connection conexion = this.getConexion();
        try {
            Statement sentencia = conexion.createStatement();
            ResultSet resultado = sentencia.executeQuery(
                                     "SELECT clave,aciertos,fecha,test FROM calificacion");
            String texto = "";
            while (resultado.next()) {
                    int id = resultado.getInt(1);
                    int aciertos = resultado.getInt(2);
                    String fecha = resultado.getString(3);
                    int test = resultado.getInt(4);
                    texto = texto + aciertos + " " + fecha + " " + test + "\n";
                }
                resultado.close();
                return texto;
        } catch (SQLException ex) {
            System.err.println(ex);
            return null;
        }
    }

    public List<Test> getTests() {
        Connection conexion = this.getConexion();
        try {
            Statement sentencia = conexion.createStatement();
            ResultSet resultado = 
                         sentencia.executeQuery("SELECT clave,nombre,preguntas FROM test");
            List<Test> lista = new ArrayList<Test>();
            while (resultado.next()) {
                    int clave  = resultado.getInt(1);
                    String nombre = resultado.getString(2);
                    int preguntas = resultado.getInt(3);
                    Test test = new Test(clave, nombre, preguntas);
                    lista.add(test);
                }
                resultado.close();
                return lista;
        } catch (SQLException ex) {
            System.err.println(ex);
            return null;
        }
    }
    
    
}
