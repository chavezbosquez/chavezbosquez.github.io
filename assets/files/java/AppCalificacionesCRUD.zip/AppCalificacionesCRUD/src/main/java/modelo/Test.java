package modelo;

/**
 *
 * @author chavez
 */
public class Test {
    int clave;
    String nombre;
    public int preguntas;

    public Test(int clave, String nombre, int preguntas) {
        this.clave = clave;
        this.nombre = nombre;
        this.preguntas = preguntas;
    }
    
    @Override
    public String toString() {
        return nombre;
    }

}
